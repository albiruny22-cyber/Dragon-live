NYXEN-DRAGON — Android V1

Isi:
- Game Monster Evolution yang dikemas sebagai aplikasi Android WebView.
- 5 tahap evolusi naga.
- Tombol poin +1 dan +10, evolve, reset.
- Level dan poin tersimpan di perangkat.
- Berjalan offline setelah terpasang.

PENTING:
- ZIP ini adalah proyek sumber Android, bukan file APK siap instal.
- APK belum dapat dikompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia.
- Workflow GitHub Actions sudah disertakan agar APK bisa dibangun di cloud tanpa laptop.

Cara build dari HP:
1. Buat akun atau masuk ke GitHub melalui browser.
2. Buat repository baru, misalnya NYXEN-DRAGON.
3. Upload seluruh isi ZIP ini ke repository (termasuk folder .github).
4. Buka tab Actions pada repository.
5. Jika diminta, izinkan Actions.
6. Pilih "Build NYXEN-DRAGON APK" lalu tekan "Run workflow".
7. Setelah selesai, buka hasil run dan unduh artifact "NYXEN-DRAGON-debug-apk".
8. Ekstrak artifact ZIP; di dalamnya ada app-debug.apk. Buka APK di Vivo Y20 dan izinkan instalasi dari sumber tersebut jika Android meminta.

Batasan V1:
- Gift TikTok belum terhubung otomatis. Poin masih ditambahkan dari tombol dalam game.
- Integrasi gift LIVE memerlukan konektor/layanan terpisah dan pengujian kompatibilitas.
